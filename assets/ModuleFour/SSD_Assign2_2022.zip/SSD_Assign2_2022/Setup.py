###############
#
# Description: This installs the application to your local machine
#              For running the application please run either:
#              the CLI (ConsoleProgram.py) or Web Api (WebProgram.py)
#
###############

from src.Repository.Installation import RepositorySetup

setupUtility = RepositorySetup()
setupUtility.Install()