#Import the Account class into main program
from Account import Account
#Import database
import data

def signup():
	#Create variable  user name and passeod
	username = input("Please enter a username  ")
	password = input("Please enter a password  ")
	print("Please wait while we perform some checks !!")
	#Create an account object  run the validate password - Hash the password then  add the account to the database
	account = Account(username, password)
	if account.validatePassword(): #This ensures that the password meets certain criteria. See the account class.
		account.hashAccountPassword() #password hadhed
		data.addAccount(account)  #adding the hashed password to the database

def login():
	username = input("Please enter a username  ")
	password = input("Please enter a password  ")
	print("Please wait while we perform some checks !!")

	account = data.getAccountByUsername(username)

	if account == None:
		print("No valid account!!")
	elif account.checkPassword(password):
		#Generating the token for the user which is displayed on the screen.TODO send as email or phone txt and do not display on screen only demo purpose.
		print(f" your token is : {account.genToken()}")
		#Remove any space entered by the user
		token = input("Please enter the one time token:  ").strip()
		#IF the token match  by calling checkToken function then we grant access
		if account.checkToken(token):
			print("Login Sucessful")
		else:
			print(" Token mismatch.")
	else:
		print("Login credentials don't match ")