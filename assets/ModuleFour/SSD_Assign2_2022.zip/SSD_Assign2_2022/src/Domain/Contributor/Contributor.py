# Person who Contributes the Evidence

class Contributor(object):

    FirstName: str = "Unknown"
    LastName: str = "Unknown"
    IdNumber: str = "Unknown"
    Email: str = "Unknown"

    #Constructor
    def __init__(self, FirstName, LastName, IdNumber, Email):
    
        self.FirstName = FirstName
        self.LastName = LastName
        self.IdNumber = IdNumber
        self.Email = Email

        