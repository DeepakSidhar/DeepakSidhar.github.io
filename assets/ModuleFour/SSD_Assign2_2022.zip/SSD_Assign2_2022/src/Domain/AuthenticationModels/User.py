# Standard User for forensice system


class User(object):

    FirstName: str = "Unknown"
    LastName: str = "Unknown"
    IdNumber: str = "Unknown"
    Email: str = "Unknown"
    Username: str
    Password: str
    
    def __init__(self, FirstName: str, LastName: str, IdNumber: str, Email: str, Username: str, Password: str):
    
        self.FirstName = FirstName
        self.LastName = LastName
        self.IdNumber = IdNumber
        self.Email = Email
        self.Username = Username
        self.Password = Password
        
        

    