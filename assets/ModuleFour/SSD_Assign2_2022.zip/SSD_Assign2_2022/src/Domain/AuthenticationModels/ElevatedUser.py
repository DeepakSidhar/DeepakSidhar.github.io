# Admin User for forensic system
import User

class ElevatedUser( User ):

    #Constructor
    def __init__(self, FirstName, LastName, IdNumber, Email):
    
        #Initialization of parent
        User.__init__(self, FirstName, LastName, IdNumber, Email)

        
        

    