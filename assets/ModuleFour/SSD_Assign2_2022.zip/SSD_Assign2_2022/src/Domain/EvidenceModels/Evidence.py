class Evidence:
    Id = "Unknown"
    Contributor = "Unknown"
    Date = "Unknown"
    Title = "Unknown"
    Binary = "0x00"
    TypeOfEvidence = "Document"

    def __init__(self, Id, Contributor, Date, Title, Binary):
        self.Id = Id
        self.Contributor = Contributor
        self.Date = Date
        self.Title = Title
        self.Binary = Binary
