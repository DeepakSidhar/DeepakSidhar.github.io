# Document type of Evidence


class Document( Evidence ):

    
    def __init__(self, Id, Contributor, Date, Title):
        Evidence.__init__(self, Id, Contributor, Date, Title)
        
        

    