# Video for forensic system
import Evidence

class Video( Evidence ):

    
    def __init__(self, Id, Contributor, Date, Title):
        Evidence.__init__(self, Id, Contributor, Date, Title)

        
        

    