import sqlite3
from datetime import date
from Domain.AuthenticationModels.User import User

class Repository(object) :

    def GetEvidences():

        connection = sqlite3.connect("ASMISDB")

        cursor = connection.cursor()

        results = cursor.execute("""

            SELECT * FROM evidence

        """, (,))

        connection.close()
        return results 

    def InsertEvidence(evidenceId,contributor,title,binary):

        connection = sqlite3.connect("ASMISDB")

        cursor = connection.cursor()

        cursor.execute("""

            INSERT INTO evidence(evidenceId,contributor,date,title,binary)
            VALUES(?,?,?,?,?)

        """, (evidenceId,contributor,date.today(),title,binary))

        connection.close()
        return True
