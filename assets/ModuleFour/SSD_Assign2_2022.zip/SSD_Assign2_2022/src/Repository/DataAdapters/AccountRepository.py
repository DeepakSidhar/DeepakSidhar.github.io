import sqlite3
from datetime import date
from Domain.AuthenticationModels.User import User

class Repository(object) :

    def GetPasswordHash(Username, Password):

        connection = sqlite3.connect("ASMISDB")

        cursor = connection.cursor()

        results = cursor.execute("""

            SELECT 1 FROM accounts where username = ?

        ;""", (Username,)).fetchall()

        connection.close()
        return results 


    def GetAccounts():

        connection = sqlite3.connect("ASMISDB")

        cursor = connection.cursor()
        

        results = cursor.execute("""

            SELECT * FROM accounts 

        ;""", (,)).fetchall()

        connection.close()
        return results 


    def InsertAccount(User: User):

        connection = sqlite3.connect("ASMISDB")

        cursor = connection.cursor()

        cursor.execute("""

            INSERT INTO accounts(firstname,lastname,idnumber,email,username,password,isElevated)
            VALUES(?,?,?,?,?,?,?)

        """, (User.firstname,User.lastname,User.idnumber,User.email,User.username,User.password,User.isElevated))

        connection.close()
        return True 