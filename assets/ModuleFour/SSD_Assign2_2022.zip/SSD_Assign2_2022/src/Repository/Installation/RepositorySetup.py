import sqlite3

class RepositorySetup:

    ##############
    #
    # Description: Creates the Sqlite Database and populates example data
    #
    ##############


    def Install(object):  
        #first time it runs, it will create a file automatically
        connection = sqlite3.connect("ASMISDB")

        cursor = connection.cursor()

        #sql lite automatically inserts a row id
        cursor.execute("""
            CREATE TABLE account 
            (
                firstname varchar(20), lastname varchar(25),
                idnumber varchar(25), email varchar(25), username varchar(25), password varchar(25),
                isElevated varchar(4) 

            )""")


        cursor.execute("INSERT INTO account (firstname,lastname,idnumber,email,username,password,isElevated) values ('James','Landon','1000007','james@1.test.com','SuperAdmin','SuperAdmin4$','True')")
        cursor.execute("INSERT INTO account (firstname,lastname,idnumber,email,username,password,isElevated) values ('George','Orwell','1377127',george@1.test.com,'George','Ethics','False')")
        cursor.execute("INSERT INTO account (firstname,lastname,idnumber,email,username,password,isElevated) values ('Geoffrey','Chaucer','1778721',geoffrey@1.test.com,'Geoffrey','Canterbury7@','False')")


        cursor.execute("""
            CREATE TABLE evidence 
            (
                id INTEGER AUTOINCREMENT,
                evidenceId VARCHAR(25), 
                contributor VARCHAR(25), 
                date VARCHAR(25), 
                title VARCHAR(25), 
                binary BLOB
            )
            """)

        cursor.execute("INSERT INTO evidence (evidenceId,contributor,date,title,binary) values ('0001','JLandon',)")
        cursor.execute("INSERT INTO evidence (evidenceId,contributor,date,title,binary) values ('0002','GOrwell',)")
        cursor.execute("INSERT INTO evidence (evidenceId,contributor,date,title,binary) values ('0003','GChaucer',)")
        cursor.execute("INSERT INTO evidence (evidenceId,contributor,date,title,binary) values ('0003','WShakespeare',)")


        cursor.execute("""
            CREATE TABLE applicationsettings 
            (
                settingId INTEGER AUTOINCREMENT, 
                key VARCHAR(20), 
                result VARCHAR(25), 
            )
            """)

        cursor.execute("INSERT INTO evidence (key,result) values ('IsWebServer','True',)")
        cursor.execute("INSERT INTO evidence (key,result) values ('Version','0.7.3',)")
        cursor.execute("INSERT INTO evidence (key,result) values ('Runtime','Python3',)")

        connection.close()

rs = RepositorySetup()
rs.Install()