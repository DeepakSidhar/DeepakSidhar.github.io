from Domain.AuthenticationModels.User import User
from Domain.EvidenceModels.Evidence import Evidence
from BusinessLogic.MainLogic import MainLogic

###########
#
#	Description: This is the CLI front end that is called from within the WebProgram
#
###########

class MainMenu(object):
	def PrintPrimaryAuthenticationMenu(self):
		print("Welcome to the Forensics Systems")
		print("")
		print("Please authenticate to continue")
		print("")

		isCorrectPassword = False
		while(isCorrectPassword == False):
			print("Please enter Username")
			username = input()
			print("Please enter Password")
			password = input()

			mainLogic = MainLogic()

			isCorrectPassword = mainLogic.Authenticate(username,password)
			if(isCorrectPassword == False):
				print("Incorrect credentials please try again")

		


	def PrintMainMenu(self):
		print("Please select a number")
		print("1 - Register User")
		print("2 - Add Evidence")
		print("3 - View Specific Evidence")
		print("4 - Get List of all authorized evidence")
		print("5 - Steganography")
		option = input()
		if(option == 1):
			self.AddUserDialogue()
		elif(option == 2):
			self.AddEvidenceDialogue()
		elif(option == 3):
			self.DisplayEvidences()
		elif(option == 4):
			self.DisplayEvidences()
		elif(option == 5):
			self.DisplayEvidences()


	def AddUserDialogue(self):

		print("Enter first name")
		firstname = input()

		print("Enter last name")
		lastname = input()

		print("Enter idnumber")
		idnumber = input()

		print("Enter email")
		email = input()

		newUser = User(firstname, lastname, idnumber, email)



	def AddEvidenceDialogue(self):

		print("Enter Id")
		id = input()

		print("Enter Contributor")
		contributor = input()

		print("Enter Date")
		date = input()

		print("Enter Title")
		title = input

		stillTryUpload = True

		fileContent

		while stillTryUpload:
			try:
				print("Enter path of file to upload")
				path = input()
				with open(path, mode='rb') as file: # b is important -> binary
					fileContent = file.read()
				stillTryUpload = False
			except:
				print("Upload failed, please try again")


		newEvidence = Evidence(id, contributor, date, title)
		newEvidence.Binary = fileContent
		MainLogic = MainLogic()

		MainLogic.AddEvidence(newEvidence)

	def DisplayEvidences():
		mainLogic = MainLogic()
		evidences = mainLogic.GetEvidences()

		for i in evidences:
			print(i.contributor + " " + i.date + " " + i.title)
