from stegano import lsb

class SteganographyUtilities:
    def HideDataInImage(directory, data, newName):
        secret = lsb.hide(directory, data)
        secret.save("./"+newName+".png")
    
    def RetrieveMessageFromImage(directory):
        message = lsb.reveal(directory)
        return message