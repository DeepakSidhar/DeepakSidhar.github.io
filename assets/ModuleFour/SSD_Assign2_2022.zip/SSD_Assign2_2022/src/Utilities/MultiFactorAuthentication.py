import pyotp

def EmailOtpAndVerify():
	pin = pyotp.TOTP('')
	#email this
	pin.now()

	userInput = input('Please enter the One Time Pin emailed to you')

	if pin.verify(userInput):
		return True
	else:
		return False

def SmsOtpAndVerify():
	pin = pyotp.TOTP('')
	#email this
	pin.now()

	userInput = input('Please enter the One Time Pin emailed to you')
	if pin.verify(userInput):
		return True
	else:
		return False
