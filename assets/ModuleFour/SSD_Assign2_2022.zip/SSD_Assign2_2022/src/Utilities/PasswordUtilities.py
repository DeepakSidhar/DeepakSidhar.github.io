# pip install bcrypt

import bcrypt
import hashlib

class PasswordUtilities:


    # Check the password length is between equal to 8 and abouve characters  but less than  or equale 10.
    def checkPassLong(password):
        if 8 <= len(password) <= 16:
            return True
        else:
            print("Password is not in range")
            return False


    # Check the password provided one upper case.
    def checkPassUpper(password):
        for letter in password:
            if letter.isupper():
                return True
        print("No upper case Characters in password:")
        return False
    # Check the password provided one lower case.
    def checkPassLower(password):
        for letter in password:
            if letter.islower():
                return True
        print("No lower case Characters in password:")
        return False
    # Check the password provided does not contain a space.
    def checkPassSpace(password):
        for letter in password:
            if letter == " ":
                print("Detected a space in password:")
                return False
        return True


    # Check the password provided contains a special character.
    def checkPassSpecial(password):
        special = ['!', '@', '#', '$', '%', '&', '*']
        for letter in password:
            if letter in special:
                return True
        print("No special characters in password:")
        return False


    # This function is invoked by the main business logic of the main program when a user is signing up. To ensure the password meet the abouve requirments.
    def validatePassword(self,password):
        return self.checkPassLong(password) \
            and self.checkPassUpper(password) \
            and self.checkPassLower(password) \
            and self.checkPassSpace(password) \
            and self.checkPassSpecial(password) 

    # This functuon uses the bcrypt library and  hashes the password  provided by the user
    def hashPasswordBcrypt(password):
        # The below is generating hash password and salt.
        hash = bcrypt.hashpw(str.encode(password), bcrypt.gensalt())
        return hash.decode()
