import bcrypt
import pyotp
import base64
import hashlib

from src.Utilities.PasswordUtilities import *


class HashingUtilities:
#Attributes of the class.
	username: str
	password: str
	token: pyotp.TOTP

#Constructor taking in the paramters username, password and token and setting the attributes above.
	def __init__(self, username, password):
		self.username = username
		self.password = password
		#Make use of base64 to handle type error.
		self.token = pyotp.TOTP(base64.b32encode(b"Hello welcome to the upload and download world!!! " + bytearray(self.username, "ascii")))

#This function uses the bcrypt library and  hashes the password  provided by the user
	def GetSha3(self,password):
		cryptoService = hashlib.sha3_224()
		cryptoService.update(b""+password)
		hashedpassword = cryptoService.hexdigest()
		return hashedpassword

#This function uses the bcrypt library and  checks  the password and hashed password
	def checkPassword(self, password):
		return bcrypt.checkpw(str.encode(password), str.encode(self.password))

	def __str__(self):
		return self.username + '-->' + self.password  #This functuon displays what is stored in the database. Please remove once live

#This function uses the one Time Password and generates a token with the username
	def genToken(self):
		return self.token.now()

#This function verfies the one Time Password
	def checkToken(self, token):
		return self.token.verify(token)
