from typing import Dict

class CachingFlyweight:
    
    def __init__():
        pass

class Caching:

    _flyweights: Dict[str, CachingFlyweight] = {}

    @staticmethod
    def GetFromCache(nameOfField):
        return self._flyweights[nameOfField]
