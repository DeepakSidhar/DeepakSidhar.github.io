from src.MenuInterface import MainMenu

menu = MainMenu()    
menu.PrintMainMenu()