from flask import Flask, request
from flask_restful import Api, reqparse, Resource
from Domain.AuthenticationModels.User import User
from src.BusinessLogic import MainLogic

Application = Flask(__name__)

@Application.route('/GetEvidence', methods = ['POST'])
def GetEvidence(self, name):
   mainLogic = MainLogic()
   accounts = mainLogic.GetEvidence()
   return accounts, 404
	
@Application.route('/UploadEvidence', methods = ['POST'])
def UploadFile():
   if request.method == 'POST':
      evidence = request.files['file']

      return 'Uploaded successful'

@Application.route('/AddEvidence', methods = ['POST'])
def post(self, FirstName, LastName):
   parser = reqparse.RequestParser()
   parser.add_argument("Id")
   parser.add_argument("Contributor")
   parser.add_argument("Date")
   parser.add_argument("Title")
   parser.add_argument("Binary")
   parser.add_argument("TypeOfEvidence")
   args = parser.parse_args()

   mainLogic = MainLogic()
   evidences = mainLogic.GetEvidences()

   for evidence in evidences:
         if(evidence == args["Binary"]):
            return "Evidence {} {} already exists.".format(FirstName, LastName), 400
   evidence = {
        "Id": args["Id"],
        "Contributor": args["Contributor"],
        "Date": args["Date"],
        "Title": args["Title"],
        "Binary": args["Binary"],
        "TypeOfEvidence": args["TypeOfEvidence"]
   }
   response = mainLogic.AddEvidence(evidence)

   return response, 201

if __name__ == '__main__':
   Application.run(debug = True)

