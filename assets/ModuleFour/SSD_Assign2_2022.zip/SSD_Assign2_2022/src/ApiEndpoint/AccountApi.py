from flask import Flask
from flask_restful import Api, reqparse, Resource
from Domain.AuthenticationModels.User import User
from src.BusinessLogic import MainLogic
 

###############################
#
# Description: This is the AccountApi responsible for accessing User Accounts
#
###############################

class AccountApi(Resource):
    Application = Flask(__name__)

    @Application.route('/DoesAccountExist', methods = ['POST'])
    def DoesAccountExist(self, name):
        mainLogic = MainLogic()
        accounts = mainLogic.GetAccounts()

        for account in accounts:
            if(name == account["name"]):
                return account, 200
        return "Account not found", 404

    @Application.route('/GetAccounts', methods = ['POST'])
    def GetAccounts(self, name):
        mainLogic = MainLogic()
        accounts = mainLogic.GetAccounts()
        return accounts, 404
 
    @Application.route('/AddAccount', methods = ['POST'])
    def AddAccount(self, FirstName, LastName):
        
        parser = reqparse.RequestParser()
        parser.add_argument("FirstName")
        parser.add_argument("LastName")
        parser.add_argument("IdNumber")
        parser.add_argument("Email")

        args = parser.parse_args()

        mainLogic = MainLogic()
        accounts = mainLogic.GetAccounts()
 
        for account in accounts:
            if(FirstName == args["FirstName"] and LastName == args["LastName"]):
                return "Account {} {} already added.".format(FirstName, LastName), 400
 
        userAccount = {
            "FirstName": args["FirstName"],
            "LastName": args["LastName"],
            "IdNumber": args["IdNumber"],
            "Email": args["Email"]
        }

        mainLogic = MainLogic()
        accounts = mainLogic.InsertAccount(userAccount)

        return userAccount, 201
 
    @Application.route('/DeleteAccount', methods = ['POST'])
    def DeleteAccount(self, name, currentUser):
        if currentUser.IsAdmin == False :
            return "Insufficient Privileges {}".format(currentUser), 400

        parser = reqparse.RequestParser()
        parser.add_argument("FirstName")
        parser.add_argument("LastName")
        parser.add_argument("IdNumber")
        parser.add_argument("Email")
        global Accounts
        Accounts = [account for account in Accounts if args["FirstName"] != FirstName and args["LastName"] != LastName]
        return "Deletion Successful.", 200

    
      

 
