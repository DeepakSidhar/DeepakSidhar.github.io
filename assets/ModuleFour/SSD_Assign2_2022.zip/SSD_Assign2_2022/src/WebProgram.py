from ApiEndpoint import AccountApi, EvidenceApi 
from flask import Flask
from flask_restful import Api, reqparse, Resource

Application = Flask(__name__)
GlobalApi = Api(Application)

##########################################################
#
# Description: Run this file to start the Flask Web Server               
#
##########################################################

GlobalApi.add_resource(AccountApi, "/Account/")
GlobalApi.add_resource(EvidenceApi, "/Evidence/")
GlobalApi.run(debug=True)