from BusinessLogic.EvidenceProcessor import EvidenceProcessor
from Repository.DataAdapters import AccountRepository
from Domain.AuthenticationModels import User
from Domain.EvidenceModels.Evidence import Video,Document,Evidence
import sys
import hashlib
import


####################################
#
# Description: Business logic layer
#
# Security: SHA-3 Hashing of the password occurs here
#
####################################

class MainLogic:
    

    def AddUser(user: User):
        repository = AccountRepository()
  
        user.Password = PasswordUtils.GetSha3()
        repository.InsertAccount(User)

    def AddEvidence(Video: Video):
        evidenceProcessor = EvidenceProcessor()
        evidenceProcessor.AddNewEvidence(Video)
    
    def Authenticate(username, password):
        
        repository = AccountRepository()

        cryptoService = hashlib.sha3_224()
        cryptoService.update(b""+user.Password)
        hashedPassword = cryptoService.hexdigest()

        existingPassword = repository.GetPasswordHash(username)

        return (hashedPassword == existingPassword)

    def GetAccounts():
        repository = AccountRepository()
        accounts = repository.GetAccounts()
        return accounts

    def GetEvidences():
        repository = AccountRepository()
        evidences = repository.GetEvidences()
        return evidences
        