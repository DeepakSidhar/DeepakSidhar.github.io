import Repository
from Domain.EvidenceModels import Video, Document, Evidence

class EvidenceProcessor(object) :

    def AddVideoEvidence(video: Video):
        repo = Repository()
        repo.InsertEvidence(video)

    def AddDocumentEvidence(document: Document):
        repo = Repository()
        repo.InsertEvidence(document)

    def AddPlainEvidence(evidence: Evidence):
        repo = Repository()
        repo.InsertEvidence(evidence)

        
    def AddEvidence(evidence: Evidence):
        if(Evidence.TypeOfEvidence == "Document"):
            self.AddDocumentEvidence(evidence)
        
        elif (Evidence.TypeOfEvidence == "Video"): 
            self.AddVideoEvidence(evidence)

        else:
            self.AddPlainEvidence(evidence)