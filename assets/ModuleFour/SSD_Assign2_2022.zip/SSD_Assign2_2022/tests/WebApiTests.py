from ApiEndpoint import AccountApi, EvidenceApi 
import pytest
from flask import Flask
from flask_restful import Api, reqparse, Resource

AccountApplication = Flask(AccountApi)
EvidenceApplication = Flask(EvidenceApi)
GlobalApi = Api(AccountApplication)
GlobalApi.run(debug=True)

###########
#
# Description: this file tests the Flask Web Api
#
###########

GlobalApi.add_resource(AccountApi, "/Account/")

#####
#gets
#####

def test_get_accounts():
    response = AccountApplication.test_client().get('/GetAccounts')

    assert response.status_code == 200
    assert response.data.decode('utf-8') == None

def test_get_evidences():
    response = EvidenceApplication.test_client().get('/GetEvidence')
    res = json.loads(response.data.decode('utf-8')).get("Book")
    print(res)
    assert res['id'] == 1
    assert res['author'] == 'Havard'
    assert res['title'] == 'CS50'
    assert response.status_code == 200

########
#inserts
########

def test_insert_accounts():
    response = AccountApplication.test_client().post('/AddAccount')

    assert response.status_code == 200
    assert response.data.decode('utf-8') == 'Testing, Flask!'

def test_insert_evidences():
    response = AccountApplication.test_client().post('/')

    assert response.status_code == 200
    assert response.data.decode('utf-8') == 'Testing, Flask!'

test_get_accounts()